"""P5 - ranking.

Sort by score (highest first), then break ties deterministically:
  1. scores are compared at 3 decimals, so 0.8333 and 0.8334 count as equal
  2. closer length to the query wins
  3. alphabetical term, then document id
"""
from __future__ import annotations

from typing import Any


def rank_results(results: list[dict[str, Any]], limit: int | None = None,
                 query: str = "") -> list[dict[str, Any]]:
    qlen = len(query.strip())

    def key(item: dict[str, Any]):
        return (-round(item["score"], 3), abs(len(item["term"]) - qlen),
                item["term"], item.get("metadata", {}).get("document_id", ""))

    ranked = sorted(results, key=key)
    if limit is not None:
        if limit < 0:
            raise ValueError("limit must be >= 0")
        ranked = ranked[:limit]
    return ranked
