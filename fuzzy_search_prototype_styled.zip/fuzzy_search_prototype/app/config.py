"""Single place for every tunable value used by the pipeline."""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATASET_PATH = os.environ.get("DATASET_PATH", os.path.join(BASE_DIR, "data", "dataset.json"))

SOURCE_NAME = "sample_dataset"   # value of "source" in every result
MAX_QUERY_LENGTH = 100           # P1 validation
DEFAULT_LIMIT = 5                # P5 default Top-N
MAX_LIMIT = 50
MIN_SCORE = 0.70                 # results below this score are dropped (see README, "False positive fix")
PARTIAL_TOKEN_PENALTY = 0.90     # query "web" vs term "web browser": partial matches never score 1.0
PREFIX_SCORE = 0.70              # query is the start of a term word ("ca" -> "card")
