"""P1 - HTTP layer (FastAPI). Every response, including errors, uses the P7 schema."""
import logging
import os

from fastapi import FastAPI, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from starlette.exceptions import HTTPException as StarletteHTTPException

from app import config, pipeline
from app.normalize import QueryError
from app.schemas import SearchResponse, error_body

log = logging.getLogger("fuzzy_search")
app = FastAPI(title="Fuzzy Search Prototype", version="1.0.0")


class SearchBody(BaseModel):
    query: str | None = None
    limit: int = config.DEFAULT_LIMIT


def _run(query, limit):
    try:
        return pipeline.search(query, limit)
    except QueryError as exc:
        return JSONResponse(error_body(exc.code, exc.message, query), status_code=exc.status)


@app.get("/api/search", response_model=SearchResponse)
def search_get(q: str | None = Query(default=None), limit: int = Query(default=config.DEFAULT_LIMIT)):
    return _run(q, limit)


@app.post("/api/search", response_model=SearchResponse)
def search_post(body: SearchBody):
    return _run(body.query, body.limit)


@app.get("/health")
def health():
    return {"status": "healthy", "index": pipeline.get_index().stats()}


@app.get("/", include_in_schema=False)
def home():
    return FileResponse(os.path.join(os.path.dirname(__file__), "static", "index.html"))


@app.get("/api")
def api_info():
    return {"message": "Fuzzy Search API", "endpoints": ["GET /api/search?q=grom", "POST /api/search", "GET /health", "GET /docs"]}


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    fields = {str(part) for err in exc.errors() for part in err.get("loc", ())}
    code = "INVALID_LIMIT" if "limit" in fields else "INVALID_REQUEST"
    return JSONResponse(error_body(code, "Request could not be validated: check query and limit"), status_code=400)


@app.exception_handler(StarletteHTTPException)
async def http_handler(request: Request, exc: StarletteHTTPException):
    code = {404: "NOT_FOUND", 405: "METHOD_NOT_ALLOWED"}.get(exc.status_code, "HTTP_ERROR")
    return JSONResponse(error_body(code, str(exc.detail)), status_code=exc.status_code)


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    log.exception("Unhandled search error")
    return JSONResponse(error_body("INTERNAL_ERROR", "An unexpected error occurred while processing the search"),
                        status_code=500)
