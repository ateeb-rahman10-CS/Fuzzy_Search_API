"""P1 - input validation and normalization."""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

from app import config


class QueryError(Exception):
    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


@dataclass
class NormalizedQuery:
    original: str
    normalized: str


def normalize_query(raw) -> NormalizedQuery:
    if raw is None:
        raise QueryError("MISSING_QUERY", "Provide a query, for example ?q=grom")
    if not isinstance(raw, str):
        raise QueryError("INVALID_QUERY", "Query must be a string")
    text = unicodedata.normalize("NFKC", raw)
    text = re.sub(r"[\x00-\x1f\x7f]", " ", text)
    text = " ".join(text.lower().split())
    if not text:
        raise QueryError("EMPTY_QUERY", "Query cannot be empty or whitespace only")
    if len(text) > config.MAX_QUERY_LENGTH:
        raise QueryError("QUERY_TOO_LONG", f"Query must not exceed {config.MAX_QUERY_LENGTH} characters")
    if not re.search(r"\w", text):
        raise QueryError("INVALID_QUERY", "Query must contain at least one letter or digit")
    return NormalizedQuery(original=raw, normalized=text)


def validate_limit(limit) -> int:
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= config.MAX_LIMIT:
        raise QueryError("INVALID_LIMIT", f"limit must be an integer between 1 and {config.MAX_LIMIT}")
    return limit
