"""P8 - the full workflow in one function.

Query -> validate/normalize -> index candidates -> score -> filter -> rank -> JSON response
"""
from __future__ import annotations

import time

from app import config
from app.index import SearchIndex
from app.normalize import normalize_query, validate_limit
from app.ranking import rank_results
from app.schemas import SearchResponse
from app.scoring import interpret, score_term

_index: SearchIndex | None = None


def get_index() -> SearchIndex:
    global _index
    if _index is None:
        _index = SearchIndex()
    return _index


def search(raw_query, limit: int = config.DEFAULT_LIMIT, index: SearchIndex | None = None) -> dict:
    started = time.perf_counter()
    index = index or get_index()
    q = normalize_query(raw_query)            # raises QueryError
    limit = validate_limit(limit)             # raises QueryError

    best_per_document: dict[str, dict] = {}
    for entry in index.candidates(q.normalized):
        scored = score_term(q.normalized, entry["term"])
        if scored.score < config.MIN_SCORE:
            continue
        doc = entry["document"]
        current = best_per_document.get(doc["id"])
        if current is None or scored.score > current["score"]:
            best_per_document[doc["id"]] = {
                "term": entry["term"],
                "score": scored.score,
                "match_quality": interpret(scored.score),
                "source": config.SOURCE_NAME,
                "metadata": {"document_id": doc["id"], "title": doc["title"],
                             "category": doc["category"], "keywords": doc.get("keywords", [])},
            }

    ranked = rank_results(list(best_per_document.values()), limit=limit, query=q.normalized)
    for position, item in enumerate(ranked, 1):
        item["rank"] = position

    response = SearchResponse(
        success=True, query=q.original, normalized_query=q.normalized,
        results=ranked, total_results=len(ranked),
        meta={"limit": limit, "min_score": config.MIN_SCORE, "engine": "bigram-index+levenshtein+soundex",
              "elapsed_ms": round((time.perf_counter() - started) * 1000, 2)},
        error=None,
    )
    return response.model_dump()
