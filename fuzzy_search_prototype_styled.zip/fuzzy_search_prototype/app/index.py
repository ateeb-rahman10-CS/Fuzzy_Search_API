"""P3 - search index.

Builds an in-memory inverted index of character bigrams over every title and keyword.
A query is turned into bigrams and only entries sharing at least one bigram become
candidates, so scoring runs on a short list instead of the whole dataset.
"""
from __future__ import annotations

import json
import re
from collections import defaultdict
from typing import Any

from app import config


def _bigrams(text: str) -> set[str]:
    grams: set[str] = set()
    for token in re.findall(r"\w+", text.lower()):
        grams.update(token[i:i + 2] for i in range(len(token) - 1))
    return grams


class SearchIndex:
    def __init__(self, dataset_path: str | None = None):
        self.dataset_path = dataset_path or config.DATASET_PATH
        self.documents: list[dict[str, Any]] = []
        self.entries: list[dict[str, Any]] = []
        self._inverted: dict[str, set[int]] = defaultdict(set)
        self._load()

    def _load(self) -> None:
        with open(self.dataset_path, "r", encoding="utf-8") as fh:
            self.documents = json.load(fh)
        for doc in self.documents:
            seen: set[str] = set()
            for raw in [doc["title"], *doc.get("keywords", [])]:
                term = raw.strip().lower()
                if not term or term in seen:
                    continue
                seen.add(term)
                position = len(self.entries)
                self.entries.append({"term": term, "document": doc})
                for gram in _bigrams(term):
                    self._inverted[gram].add(position)

    def candidates(self, query: str) -> list[dict[str, Any]]:
        """Entries that share at least one bigram with the query. Empty if the query has no bigram."""
        hits: set[int] = set()
        for gram in _bigrams(query):
            hits |= self._inverted.get(gram, set())
        return [self.entries[i] for i in sorted(hits)]

    def stats(self) -> dict[str, int]:
        return {"documents": len(self.documents), "indexed_terms": len(self.entries),
                "bigrams": len(self._inverted)}
