"""P4 - similarity scoring. One scale everywhere: 0.0 (unrelated) to 1.0 (identical).

score()            edit-distance ratio (rapidfuzz, pure-Python fallback) plus a small Soundex boost.
score_term()       adds token-level scoring so multi-word terms ("credit card") and partial
                   queries ("web" -> "web browser") work.
interpret()        maps a score to a label so consumers do not have to guess.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from app import config

try:
    from rapidfuzz import fuzz
    _HAVE_RAPIDFUZZ = True
except ImportError:  # pragma: no cover
    _HAVE_RAPIDFUZZ = False

PHONETIC_BOOST = 0.05
NOT_EXACT_CAP = 0.99
_SOUNDEX = {**{c: "1" for c in "BFPV"}, **{c: "2" for c in "CGJKQSXZ"},
            **{c: "3" for c in "DT"}, "L": "4", **{c: "5" for c in "MN"}, "R": "6"}


def _levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i] + [0] * len(b)
        for j, cb in enumerate(b, 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb))
        prev = cur
    return prev[-1]


def _ratio(a: str, b: str) -> float:
    """Normalized similarity in [0, 1]."""
    if _HAVE_RAPIDFUZZ:
        return fuzz.ratio(a, b) / 100.0
    total = len(a) + len(b)
    return 1.0 if total == 0 else 1 - _levenshtein(a, b) / total


def soundex(word: str) -> str:
    word = "".join(ch for ch in word.upper() if ch.isalpha())
    if not word:
        return ""
    out, prev = [word[0]], _SOUNDEX.get(word[0], "")
    for ch in word[1:]:
        code = _SOUNDEX.get(ch, "")
        if code and code != prev:
            out.append(code)
        prev = code
    return ("".join(out) + "000")[:4]


@dataclass
class ScoredCandidate:
    candidate: str
    score: float
    edit_ratio: float
    phonetic_match: bool


def score(query: str, candidate: str) -> ScoredCandidate:
    q, c = query.strip().lower(), candidate.strip().lower()
    ratio = _ratio(q, c)
    phonetic = bool(q) and soundex(q) == soundex(c)
    blended = min(ratio + (PHONETIC_BOOST if phonetic and ratio < 1.0 else 0.0), 1.0)
    if q != c:
        blended = min(blended, NOT_EXACT_CAP)   # only a string-identical match may score 1.0
    return ScoredCandidate(candidate, round(blended, 4), round(ratio, 4), phonetic)


def _tokens(text: str) -> list[str]:
    return re.findall(r"\w+", text.lower())


def score_term(query: str, term: str) -> ScoredCandidate:
    """Best of: whole-string score, or average best-token score."""
    best = score(query, term)
    q_tokens, t_tokens = _tokens(query), _tokens(term)
    if q_tokens and t_tokens:
        token_score = sum(max(score(qt, tt).score for tt in t_tokens) for qt in q_tokens) / len(q_tokens)
        if len(t_tokens) > len(q_tokens):
            token_score *= config.PARTIAL_TOKEN_PENALTY
        token_score = round(min(token_score, NOT_EXACT_CAP), 4)
        # short prefix ("ca" -> "card") gets a fixed medium score instead of a low edit-distance score
        if any(len(qt) >= 2 and tt.startswith(qt) and tt != qt for qt in q_tokens for tt in t_tokens):
            token_score = max(token_score, config.PREFIX_SCORE)
        if token_score > best.score:
            best = ScoredCandidate(term, token_score, best.edit_ratio, best.phonetic_match)
    return best


def interpret(value: float) -> str:
    if value >= 0.90:
        return "very_high"
    if value >= 0.75:
        return "high"
    if value >= 0.70:
        return "medium"
    return "low"
