"""P7 - the one response format every component uses."""
from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel


class ResultMetadata(BaseModel):
    document_id: str
    title: str
    category: str
    keywords: list[str]


class SearchResult(BaseModel):
    rank: int
    term: str
    score: float
    match_quality: str
    source: str
    metadata: ResultMetadata


class ResponseMeta(BaseModel):
    limit: int
    min_score: float
    engine: str
    elapsed_ms: float


class ErrorInfo(BaseModel):
    code: str
    message: str


class SearchResponse(BaseModel):
    success: bool
    query: Optional[str]
    normalized_query: Optional[str]
    results: list[SearchResult]
    total_results: int
    meta: Optional[ResponseMeta] = None
    error: Optional[ErrorInfo] = None


def error_body(code: str, message: str, query: Any = None) -> dict:
    return {"success": False, "query": query if isinstance(query, str) else None,
            "normalized_query": None, "results": [], "total_results": 0,
            "meta": None, "error": {"code": code, "message": message}}
