# Fuzzy Search Prototype (P1 to P8, integrated)

One service that takes a misspelled query such as `grom` and returns ranked matches from a small dataset.

```
User Query
   -> Search API        app/main.py        (P1)  validation: app/normalize.py
   -> Search Index      app/index.py       (P3)  bigram inverted index over data/dataset.json
   -> Fuzzy Matching    app/scoring.py     (P2 role, done by P4 scorer)
   -> Similarity Score  app/scoring.py     (P4)  0.0 to 1.0
   -> Result Ranking    app/ranking.py     (P5)
   -> JSON Response     app/schemas.py     (P7)  schema/response.schema.json
```
`app/pipeline.py` runs the whole chain in one function. The API only calls `pipeline.search()`.

## Setup and run (one machine, Python 3.10+)

```bash
pip install -r requirements.txt
python run.py            # API at http://127.0.0.1:8000  (interactive docs: /docs)
```
In a second terminal:
```bash
curl "http://127.0.0.1:8000/api/search?q=grom"
python demo.py           # prints every stage for 5 queries, then a success and an error response
python -m pytest -q      # 75 tests
python generate_report.py  # rewrites TEST_REPORT.md (22 cases through the full pipeline)
```

### Running just the index (P3), without the API

Teammates who only need the index/matching layer, not the HTTP service, can run it directly:

```bash
python index_cli.py grom              # query the index and print ranked JSON results
python index_cli.py --stats           # document/term/bigram counts, no query
python index_cli.py grom --dataset path/to/other_dataset.json   # point at a different dataset
```

`index_cli.py` loads `data/dataset.json` (same file the API uses) and calls the same
`app/index.py`, `app/scoring.py` and `app/ranking.py` code, so results match `/api/search`
exactly — it just skips FastAPI, HTTP, and the request-validation layer.

## Endpoint

| Method | Path | Input |
|---|---|---|
| GET | `/api/search?q=grom&limit=5` | `q` required, `limit` optional (1 to 50, default 5) |
| POST | `/api/search` | JSON body `{"query": "grom", "limit": 5}` |
| GET | `/health` | none. Returns index size |

### Example request and response

`GET /api/search?q=credti%20card&limit=2`
```json
{
  "success": true,
  "query": "credti card",
  "normalized_query": "credti card",
  "results": [
    {"rank": 1, "term": "credit card", "score": 0.9166, "match_quality": "very_high", "source": "sample_dataset",
     "metadata": {"document_id": "doc-01", "title": "Credit Card", "category": "Finance",
                  "keywords": ["credit card", "banking", "payment", "card limit"]}},
    {"rank": 2, "term": "debit card", "score": 0.825, "match_quality": "high", "source": "sample_dataset",
     "metadata": {"document_id": "doc-02", "title": "Debit Card", "category": "Finance",
                  "keywords": ["debit card", "banking", "atm", "account"]}}
  ],
  "total_results": 2,
  "meta": {"limit": 2, "min_score": 0.7, "engine": "bigram-index+levenshtein+soundex", "elapsed_ms": 1.1},
  "error": null
}
```

Error example, `GET /api/search?q=%20%20` (HTTP 400):
```json
{"success": false, "query": "  ", "normalized_query": null, "results": [], "total_results": 0,
 "meta": null, "error": {"code": "EMPTY_QUERY", "message": "Query cannot be empty or whitespace only"}}
```
A valid query with no match is **not** an error: HTTP 200, `success: true`, `results: []`, `total_results: 0`.

### Response fields (schema: `schema/response.schema.json`)

| Field | Meaning |
|---|---|
| `success` | `true` for a completed search, `false` for an error |
| `query` | Query exactly as sent, or `null` if none was sent |
| `normalized_query` | Trimmed, lower-cased, spaces collapsed. `null` on errors |
| `results[].rank` | 1 is the best match |
| `results[].term` | The indexed term that matched (this is the `term` field from the P7 brief) |
| `results[].score` | Similarity, 0.0 to 1.0. Only an identical string scores 1.0 |
| `results[].match_quality` | `very_high` >= 0.90, `high` >= 0.75, `medium` >= 0.70 |
| `results[].source` | Dataset name, `sample_dataset` |
| `results[].metadata` | `document_id`, `title`, `category`, `keywords` of the matched document |
| `total_results` | Number of items in `results` (after the limit) |
| `meta` | `limit`, `min_score`, `engine`, `elapsed_ms`. `null` on errors |
| `error` | `null` on success, otherwise `{code, message}` |

Error codes: `MISSING_QUERY`, `EMPTY_QUERY`, `QUERY_TOO_LONG` (over 100 characters), `INVALID_QUERY`, `INVALID_LIMIT`, `INVALID_REQUEST`, `NOT_FOUND`, `METHOD_NOT_ALLOWED`, `INTERNAL_ERROR` (HTTP 500, no internal details exposed).

Each document appears at most once. If several of its keywords match, the best one is shown.

## Integration decisions

| Issue found in P1 to P7 | Decision |
|---|---|
| Two score scales (P2 used 0 to 100) | One scale, 0.0 to 1.0, everywhere |
| Three separate matchers and datasets (P1 `difflib`, P3 Levenshtein, P7 mock data) | One dataset (P3's `dataset.json`), one scorer (P4). P1's hardcoded word list and P7's mock pipeline are removed |
| P2 vs P4 scoring | P4 kept. P2's `WRatio` returns 0 to 100 and overlaps P4. Both use `rapidfuzz`, so the approach is the same |
| Field names `match` (P7), `matched_term` (P1, P2, P3), `term` (brief) | `term`, as in the brief |
| Flask (P1) vs FastAPI (P7) | FastAPI: gives request validation, `/docs` and pydantic response models. The path `/api/search?q=` from P1 is unchanged |
| P5 ranking used `match` and a stable sort | Uses `term`. Ties are settled by 3-decimal score, then length closest to the query, then alphabetical, so order never depends on input order |

### The `banana` false positive from P6

P6 found `banana` returning `Credit Card` at 0.571. In the integrated pipeline the minimum score is 0.70, so it returns nothing. While testing I found a second one, `elephant` matching `element` at 0.667, which the same threshold removes.
Be aware that 0.70 was chosen by looking at these examples and this 8-document dataset. Re-tune it (`MIN_SCORE` in `app/config.py`) when the dataset grows.

## Approach comparison (P2)

Two approaches were considered for the matching layer:

| Approach | Pros | Cons | Verdict |
|---|---|---|---|
| **Edit distance / Levenshtein** (`rapidfuzz`, pure-Python fallback) | No extra service to run; deterministic; easy to unit test in isolation; score is directly interpretable (0 to 1 = how many edits apart) | O(len(a)*len(b)) per comparison, so it needs the bigram index (P3) to cut candidates first rather than scoring every term in the dataset | **Chosen.** Fits an in-process prototype with a small dataset and no infra dependency |
| **Search engine's built-in fuzzy matching** (e.g. Elasticsearch/OpenSearch `fuzzy` query, PostgreSQL `pg_trgm`) | Scales far better on large datasets; fuzziness, indexing and ranking are one system; production-proven | Extra service to install/run/version just for this prototype; fuzziness is usually bounded to Damerau-Levenshtein distance <= 2, which is coarser than a real 0 to 1 similarity score; harder for teammates to run locally with one command | Rejected **for the prototype** — revisit if/when this moves off a small in-memory dataset |

Both are Levenshtein-family algorithms at their core; the difference is where the computation runs (in-process vs. a separate indexed engine), not the underlying math. If the dataset grows past what fits in memory, swapping `app/index.py`'s candidate lookup for a real engine's fuzzy query is the natural next step — `app/scoring.py` and everything downstream would not need to change.

## Scoring in short

1. `rapidfuzz` edit-distance ratio, 0 to 1, on lower-cased text.
2. +0.05 when Soundex codes match (helps sound-alike typos).
3. For multi-word terms, the average best-word score is also computed. Partial matches (`web` for `web browser`) are multiplied by 0.90.
4. A query that is the start of a word (`ca` for `card`, 2+ letters) gets 0.70.
5. Anything not string-identical is capped at 0.99. Scores under 0.70 are dropped.

## Known limits

- The bigram index only shortlists terms that share a two-letter pair with the query. `a` and `ps` return nothing.
- Two wrong letters in a 4-letter word scores 0.50 and is not returned.
- Prefix matches are fixed at 0.70, so they rank below typo matches of longer words.
- The index is in memory and loaded once at startup. Editing `data/dataset.json` needs a restart. Set another file with the `DATASET_PATH` environment variable.

## Tests

`tests/test_units.py` (normalization, scoring, ranking, index), `tests/test_api.py` (endpoint, errors, every response validated against the JSON schema), `tests/test_p6_cases.py` (22 cases through the full pipeline). Results table: `TEST_REPORT.md`.

## Project layout

```
app/        config, normalize, index, scoring, ranking, schemas, pipeline, main
data/       dataset.json
schema/     response.schema.json
tests/      unit, API and P6 case tests
demo.py  generate_report.py  run.py  index_cli.py  TEST_REPORT.md
```
