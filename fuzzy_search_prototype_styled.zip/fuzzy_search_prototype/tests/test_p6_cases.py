"""P6 cases run through the FULL integrated pipeline (not the index alone)."""
import pytest

from tests.p6_cases import CASES, evaluate


@pytest.mark.parametrize("case", CASES, ids=[c["id"] for c in CASES])
def test_case(client, case):
    body = client.get("/api/search", params={"q": case["input"]}).json()
    ok, _ = evaluate(case, body)
    assert ok
