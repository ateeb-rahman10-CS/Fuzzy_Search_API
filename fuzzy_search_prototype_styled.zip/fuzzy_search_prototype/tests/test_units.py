import pytest

from app.index import SearchIndex
from app.normalize import QueryError, normalize_query, validate_limit
from app.ranking import rank_results
from app.scoring import interpret, score, score_term


# ---- P1 normalization
def test_normalize_trims_lowercases_collapses():
    assert normalize_query("  CrEdTi   CARD ").normalized == "credti card"


def test_normalize_keeps_original():
    assert normalize_query("  Grom ").original == "  Grom "


@pytest.mark.parametrize("raw,code", [(None, "MISSING_QUERY"), ("", "EMPTY_QUERY"), ("   ", "EMPTY_QUERY"),
                                       ("x" * 101, "QUERY_TOO_LONG"), ("!!!", "INVALID_QUERY"), (123, "INVALID_QUERY")])
def test_normalize_errors(raw, code):
    with pytest.raises(QueryError) as exc:
        normalize_query(raw)
    assert exc.value.code == code


@pytest.mark.parametrize("bad", [0, -1, 51, "5", 2.5, True])
def test_limit_invalid(bad):
    with pytest.raises(QueryError):
        validate_limit(bad)


# ---- P4 scoring
def test_identical_is_one():
    assert score("passport", "passport").score == 1.0


def test_typo_scores_high_and_unrelated_low():
    assert score("grom", "brom").score >= 0.75
    assert score("grom", "encryption").score < 0.4


@pytest.mark.parametrize("q,t,minimum", [("credti card", "credit card", 0.85), ("ransomare", "ransomware", 0.9),
                                          ("passpord", "passport", 0.9), ("pasport", "passport", 0.9)])
def test_typo_examples(q, t, minimum):
    assert score_term(q, t).score >= minimum


def test_score_always_in_range():
    for a, b in [("", "x"), ("x", ""), ("abc", "xyz"), ("same", "same")]:
        assert 0.0 <= score(a, b).score <= 1.0


def test_partial_never_scores_one():
    assert score_term("web", "web browser").score < 1.0


def test_interpret_bands():
    assert [interpret(v) for v in (1.0, 0.8, 0.7, 0.2)] == ["very_high", "high", "medium", "low"]


# ---- P5 ranking
def _r(term, sc, doc="d"):
    return {"term": term, "score": sc, "metadata": {"document_id": doc}}


def test_rank_orders_by_score():
    out = rank_results([_r("gram", .76), _r("brom", .91), _r("broom", .64)])
    assert [r["term"] for r in out] == ["brom", "gram", "broom"]


def test_rank_limit():
    assert len(rank_results([_r(str(i), i / 10) for i in range(10)], limit=3)) == 3


def test_rank_tie_is_deterministic_regardless_of_input_order():
    a, b = _r("beta", .8, "2"), _r("alpha", .8, "1")
    assert rank_results([a, b]) == rank_results([b, a])


def test_rank_near_equal_scores_treated_as_tie():
    out = rank_results([_r("zzzz", .83334), _r("aaaa", .83331)])
    assert out[0]["term"] == "aaaa"


def test_rank_empty():
    assert rank_results([], limit=5) == []


# ---- P3 index
def test_index_loads():
    idx = SearchIndex()
    assert idx.stats()["documents"] == 8


def test_index_candidates_include_typo_target():
    terms = [e["term"] for e in SearchIndex().candidates("ransomare")]
    assert "ransomware" in terms


def test_index_no_bigram_no_candidates():
    assert SearchIndex().candidates("a") == []


def test_only_identical_strings_score_one():
    assert score("creditcard", "credit card").score < 1.0
    assert score_term("card credit", "credit card").score < 1.0
    assert score_term("credit card", "credit card").score == 1.0
