import json
import os
import sys

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.main import app  # noqa: E402


@pytest.fixture(scope="session")
def client():
    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture(scope="session")
def schema():
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "schema", "response.schema.json")
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)
