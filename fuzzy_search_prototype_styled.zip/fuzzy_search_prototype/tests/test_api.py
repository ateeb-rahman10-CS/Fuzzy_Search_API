import jsonschema
import pytest


def _valid(body, schema):
    jsonschema.validate(body, schema)


@pytest.mark.parametrize("q,top", [("grom", "brom"), ("credti card", "credit card"),
                                    ("ransomare", "ransomware"), ("passpord", "passport")])
def test_brief_examples(client, schema, q, top):
    r = client.get("/api/search", params={"q": q})
    body = r.json()
    assert r.status_code == 200 and body["success"] is True
    assert body["results"][0]["term"] == top
    assert body["query"] == q
    _valid(body, schema)


def test_response_fields(client):
    body = client.get("/api/search", params={"q": "grom"}).json()
    item = body["results"][0]
    assert item["source"] == "sample_dataset" and item["rank"] == 1
    assert body["total_results"] == len(body["results"])
    assert body["meta"]["limit"] == 5 and body["error"] is None


def test_original_and_normalized_query(client):
    body = client.get("/api/search", params={"q": "  GROM "}).json()
    assert body["query"] == "  GROM " and body["normalized_query"] == "grom"


def test_post(client, schema):
    r = client.post("/api/search", json={"query": "passpord", "limit": 1})
    assert r.status_code == 200 and r.json()["total_results"] == 1
    _valid(r.json(), schema)


def test_limit_applies(client):
    assert client.get("/api/search", params={"q": "card", "limit": 1}).json()["total_results"] == 1


def test_no_match_is_success_with_empty_results(client, schema):
    r = client.get("/api/search", params={"q": "zzxxqqyy"})
    assert r.status_code == 200 and r.json()["results"] == [] and r.json()["total_results"] == 0
    _valid(r.json(), schema)


@pytest.mark.parametrize("params,code", [
    ({}, "MISSING_QUERY"), ({"q": ""}, "EMPTY_QUERY"), ({"q": "   "}, "EMPTY_QUERY"),
    ({"q": "x" * 101}, "QUERY_TOO_LONG"), ({"q": "???"}, "INVALID_QUERY"),
    ({"q": "grom", "limit": 0}, "INVALID_LIMIT"), ({"q": "grom", "limit": "abc"}, "INVALID_LIMIT"),
    ({"q": "grom", "limit": 999}, "INVALID_LIMIT"),
])
def test_errors_use_same_schema(client, schema, params, code):
    r = client.get("/api/search", params=params)
    assert r.status_code == 400
    assert r.json()["error"]["code"] == code and r.json()["success"] is False
    _valid(r.json(), schema)


def test_post_bad_body(client, schema):
    r = client.post("/api/search", json={"limit": 3})
    assert r.status_code == 400 and r.json()["error"]["code"] == "MISSING_QUERY"
    _valid(r.json(), schema)


def test_404_and_405_use_error_schema(client, schema):
    assert client.get("/nope").json()["error"]["code"] == "NOT_FOUND"
    r = client.put("/api/search")
    assert r.status_code == 405 and r.json()["error"]["code"] == "METHOD_NOT_ALLOWED"
    _valid(r.json(), schema)


def test_internal_error_is_json(client, schema, monkeypatch):
    from app import pipeline

    def boom(*a, **k):
        raise RuntimeError("index exploded")

    monkeypatch.setattr(pipeline, "search", boom)
    r = client.get("/api/search", params={"q": "grom"})
    assert r.status_code == 500 and r.json()["error"]["code"] == "INTERNAL_ERROR"
    assert "exploded" not in r.text
    _valid(r.json(), schema)


def test_health(client):
    assert client.get("/health").json()["status"] == "healthy"
