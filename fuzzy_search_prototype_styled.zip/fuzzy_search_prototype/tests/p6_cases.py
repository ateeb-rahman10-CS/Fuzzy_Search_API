"""P6 test dataset. 'expect' shapes: top (best result title), any_top, all_of, none, error (code)."""

CASES = [
    {"id": "TC01", "category": "Correct spelling", "input": "passport", "expect": {"top": "Passport"}},
    {"id": "TC02", "category": "Correct spelling", "input": "firewall", "expect": {"top": "Firewall"}},
    {"id": "TC03", "category": "Character substitution", "input": "grom", "expect": {"top": "Brom"}},
    {"id": "TC04", "category": "Character substitution", "input": "credti card", "expect": {"top": "Credit Card"}},
    {"id": "TC05", "category": "Missing character", "input": "pasport", "expect": {"top": "Passport"}},
    {"id": "TC06", "category": "Missing character", "input": "ransomare", "expect": {"top": "Ransomware"}},
    {"id": "TC07", "category": "Extra character", "input": "firewalll", "expect": {"top": "Firewall"}},
    {"id": "TC08", "category": "Extra character", "input": "ransomwaree", "expect": {"top": "Ransomware"}},
    {"id": "TC09", "category": "Unrelated word", "input": "banana", "expect": {"none": True}},
    {"id": "TC10", "category": "Unrelated word", "input": "zzxxqqyy", "expect": {"none": True}},
    {"id": "TC11", "category": "Empty query", "input": "", "expect": {"error": "EMPTY_QUERY"}},
    {"id": "TC12", "category": "Empty query (spaces)", "input": "   ", "expect": {"error": "EMPTY_QUERY"}},
    {"id": "TC13", "category": "Very short query", "input": "ca", "expect": {"any_top": ["Credit Card", "Debit Card"]}},
    {"id": "TC14", "category": "Very short query", "input": "a", "expect": {"none": True}},
    {"id": "TC15", "category": "Multiple possible matches", "input": "card", "expect": {"all_of": ["Credit Card", "Debit Card"]}},
    {"id": "TC16", "category": "Multiple possible matches", "input": "web", "expect": {"any_top": ["Web Browser"]}},
    {"id": "TC17", "category": "Typo, phonetic", "input": "passpord", "expect": {"top": "Passport"}},
    {"id": "TC18", "category": "Missing character", "input": "databse", "expect": {"top": "Database Engine"}},
    {"id": "TC19", "category": "Extra character", "input": "malwaree", "expect": {"top": "Ransomware"}},
    {"id": "TC20", "category": "Mixed case and spaces", "input": "  FIREWAL ", "expect": {"top": "Firewall"}},
    {"id": "TC21", "category": "Unrelated word", "input": "elephant", "expect": {"none": True}},
    {"id": "TC22", "category": "Too long", "input": "x" * 101, "expect": {"error": "QUERY_TOO_LONG"}},
]


def _titles(body):
    return [r["metadata"]["title"] for r in body["results"]]


def evaluate(case, body):
    """Return (passed, description_of_expectation)."""
    e = case["expect"]
    titles = _titles(body)
    if "error" in e:
        return (body["success"] is False and body["error"]["code"] == e["error"]), f"error {e['error']}"
    if not body["success"]:
        return False, "success"
    if e.get("none"):
        return titles == [], "no results"
    if "top" in e:
        return bool(titles) and titles[0] == e["top"], f"top = {e['top']}"
    if "any_top" in e:
        return bool(titles) and titles[0] in e["any_top"], "top in " + " / ".join(e["any_top"])
    if "all_of" in e:
        return all(t in titles for t in e["all_of"]), "contains " + " + ".join(e["all_of"])
    return False, "unknown"
